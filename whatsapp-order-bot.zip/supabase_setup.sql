-- Run this in Supabase → SQL Editor
CREATE TABLE whatsapp_orders (
  id SERIAL PRIMARY KEY,
  phone TEXT NOT NULL,
  name TEXT,
  item TEXT,
  quantity TEXT,
  address TEXT,
  status TEXT DEFAULT 'new',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Allow anon inserts (since you're using publishable key)
ALTER TABLE whatsapp_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anon insert" ON whatsapp_orders
  FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Allow anon select" ON whatsapp_orders
  FOR SELECT TO anon USING (true);
