require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(express.json());

// Supabase
const supabase = createClient(
  'https://cnibkphbjautasggyiia.supabase.co',
  'sb_publishable_mUKU80NAIYmS1Gk-S22nAQ_JMZNp1BJ'
);

// WhatsApp config — fill these in .env
const WA_TOKEN = process.env.WA_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || 'abuja_ops_verify';

// In-memory session store (per user conversation state)
const sessions = {};

// ─── WEBHOOK VERIFY (Meta handshake) ─────────────────────────────────────────
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Webhook verified');
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

// ─── INCOMING MESSAGES ────────────────────────────────────────────────────────
app.post('/webhook', async (req, res) => {
  res.sendStatus(200); // always ack fast

  const entry = req.body?.entry?.[0];
  const change = entry?.changes?.[0];
  const message = change?.value?.messages?.[0];
  if (!message) return;

  const from = message.from;         // customer's WhatsApp number
  const text = message.text?.body?.trim().toLowerCase();
  if (!text) return;

  console.log(`📩 From ${from}: ${text}`);

  await handleMessage(from, text);
});

// ─── CONVERSATION STATE MACHINE ───────────────────────────────────────────────
async function handleMessage(from, text) {
  if (!sessions[from]) sessions[from] = { step: 'idle' };
  const session = sessions[from];

  // Start order
  if (text.includes('order') || text.includes('hi') || text.includes('hello') || session.step === 'idle') {
    if (session.step === 'idle' || text.includes('order') || text.includes('hi') || text.includes('hello')) {
      sessions[from] = { step: 'ask_name' };
      return send(from, `👋 Welcome to *Abuja Ops*!\n\nLet's capture your order. First, what's your *full name*?`);
    }
  }

  switch (session.step) {
    case 'ask_name':
      session.name = text;
      session.step = 'ask_item';
      return send(from, `Got it, *${capitalize(text)}*! 🙌\n\nWhat would you like to *order*? (describe the item/service)`);

    case 'ask_item':
      session.item = text;
      session.step = 'ask_qty';
      return send(from, `Nice! How many units or what *quantity*?`);

    case 'ask_qty':
      session.qty = text;
      session.step = 'ask_address';
      return send(from, `And your *delivery address* in Abuja?`);

    case 'ask_address':
      session.address = text;
      session.step = 'confirm';
      return send(from,
        `📋 *Order Summary*\n\n` +
        `👤 Name: ${capitalize(session.name)}\n` +
        `📦 Item: ${session.item}\n` +
        `🔢 Qty: ${session.qty}\n` +
        `📍 Address: ${session.address}\n\n` +
        `Reply *YES* to confirm or *NO* to restart.`
      );

    case 'confirm':
      if (text === 'yes') {
        await saveOrder(from, session);
        sessions[from] = { step: 'idle' };
        return send(from, `✅ Order confirmed and logged! Our team will reach out shortly.\n\nType *order* anytime to place a new one.`);
      } else {
        sessions[from] = { step: 'idle' };
        return send(from, `❌ Order cancelled. Type *order* to start again.`);
      }

    default:
      sessions[from] = { step: 'idle' };
      return send(from, `Type *order* to place an order 👇`);
  }
}

// ─── SAVE TO SUPABASE ─────────────────────────────────────────────────────────
async function saveOrder(phone, session) {
  const { data, error } = await supabase
    .from('whatsapp_orders')
    .insert([{
      phone,
      name: capitalize(session.name),
      item: session.item,
      quantity: session.qty,
      address: session.address,
      status: 'new',
      created_at: new Date().toISOString()
    }]);

  if (error) console.error('❌ Supabase error:', error.message);
  else console.log('✅ Order saved to Supabase:', data);
}

// ─── SEND WHATSAPP MESSAGE ────────────────────────────────────────────────────
async function send(to, body) {
  try {
    await axios.post(
      `https://graph.facebook.com/v19.0/${PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: 'whatsapp',
        to,
        type: 'text',
        text: { body }
      },
      {
        headers: {
          Authorization: `Bearer ${WA_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log(`📤 Sent to ${to}`);
  } catch (err) {
    console.error('❌ Send error:', err.response?.data || err.message);
  }
}

function capitalize(str) {
  return str.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

// ─── START SERVER ─────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Bot running on port ${PORT}`));
